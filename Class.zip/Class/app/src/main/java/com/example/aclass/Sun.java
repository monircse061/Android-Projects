package com.example.aclass;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

;

public class Sun extends Fragment {

    public Sun() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_blank, container, false);
        RecyclerView rv = (RecyclerView) rootView.findViewById(R.id.rv_recycler_view);
        rv.setHasFixedSize(true);

        MyAdapter adapter = new MyAdapter(new String[]{"MicroProcessor", "MicroProcessor Lab", "Software Engineering"},
                new String[] {"CSE357","CSE358","CSE359"},
                new String[]{" 10.00 AM - 11.00 AM ", " 11.00 AM - 01.00 PM", " 02.00 PM - 03.00 PM "},
                new String[]{" 407 ", " 411", " 407 "},
                new String[]{"S.M Mehedy Hassan ", "S.M Mehedy Hassan", " Sakifa Aktar "}
        );

        rv.setAdapter(adapter);

        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        rv.setLayoutManager(llm);

        return rootView;
    }

}