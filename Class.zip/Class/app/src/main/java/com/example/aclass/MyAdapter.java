package com.example.aclass;

import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by delaroy on 2/13/17.
 */
public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private String[] Time,Course,Room,Teacher,Code;

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        public CardView mCardView;
        public TextView Course_tv,Time_tv,Room_tv,Teacher_tv,code_tv;
        public MyViewHolder(View v){
            super(v);

            mCardView = (CardView) v.findViewById(R.id.card_view);
            Course_tv = (TextView) v.findViewById(R.id.tv_text);
            code_tv = (TextView) v.findViewById(R.id.tv_text1);
            Time_tv = (TextView) v.findViewById(R.id.tv_text2);
            Room_tv = (TextView) v.findViewById(R.id.tv_text3);
            Teacher_tv = (TextView) v.findViewById(R.id.tv_text4);

        }

    }

    public MyAdapter(String[] course,String[] code,String[] time,String[] room,String[] teacher){
        Course = course;
        Code = code;
        Time = time;
        Room = room;
        Teacher = teacher;
    }

    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position){
        holder.Course_tv.setText(Course[position]);
        holder.code_tv.setText(Code[position]);
        holder.Time_tv.setText(Time[position]);
        holder.Room_tv.setText(Room[position]);
        holder.Teacher_tv.setText(Teacher[position]);
    }

    @Override
    public int getItemCount() { return Course.length; }

}
